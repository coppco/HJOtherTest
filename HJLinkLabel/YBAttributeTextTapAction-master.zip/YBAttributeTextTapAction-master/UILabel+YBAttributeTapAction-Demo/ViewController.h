//
//  ViewController.h
//  UILabel+YBAttributeTapAction-Demo
//
//  Created by LYB on 16/7/1.
//  Copyright © 2016年 LYB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

