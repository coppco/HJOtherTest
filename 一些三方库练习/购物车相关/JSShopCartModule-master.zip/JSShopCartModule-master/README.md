***********
>购物车模板
==
>>RAC && MVVM
--
##*力求用最简洁的代码解决问题(主要是RAC太nice了)
##*这是一个购物车模板,因为项目使用到了,所以分享一下自己的经验.
##*如果觉得还行,或者还ok,请右上角点个star,谢谢~~~
##*还如果程序中有不足或不懂得都可以issue我.
![image](https://github.com/Josin22/JSShopCartModule/blob/master/Source/gig1.gif)
***********
