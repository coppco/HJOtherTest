//
//  AppDelegate.h
//  JSShopCartModule
//
//  Created by 乔同新 on 16/6/8.
//  Copyright © 2016年 乔同新. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

