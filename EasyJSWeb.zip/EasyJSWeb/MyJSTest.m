//
//  MyTest.m
//  HeXunRongHeJinFu
//
//  Created by SKY on 15/12/29.
//  Copyright © 2015年 SKY. All rights reserved.
//

#import "MyJSTest.h"

@implementation MyJSTest
- (void)JSWithType:(NSString*)type AndJsonString:(NSString *)string{
    [_delegate JSWithType:type AndJsonString:string];
}


@end
