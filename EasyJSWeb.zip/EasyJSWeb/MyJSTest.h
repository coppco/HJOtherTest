//
//  MyTest.h
//  HeXunRongHeJinFu
//
//  Created by SKY on 15/12/29.
//  Copyright © 2015年 SKY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>

@protocol MyJSTestDelegate<JSExport>
- (void)JSWithType:(NSString*)type AndJsonString:(NSString *)string;
@end

@interface MyJSTest : NSObject<MyJSTestDelegate>
@property (nonatomic, assign) id<MyJSTestDelegate> delegate;
@end
